package com.example.dalyakhatun.procastinator;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by dalyakhatun on 10/28/17.
 */

public class activity_list extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
    }
}
