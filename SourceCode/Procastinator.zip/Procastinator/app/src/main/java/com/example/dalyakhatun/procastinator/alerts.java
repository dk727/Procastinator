package com.example.dalyakhatun.procastinator;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by dalyakhatun on 10/28/17.
 */

public class alerts extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.alerts);
    }
}
