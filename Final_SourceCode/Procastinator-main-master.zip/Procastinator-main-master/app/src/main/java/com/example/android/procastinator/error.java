package com.example.android.procastinator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * Created by Kevin on 11/25/2017.
 */

public class error extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.error);
    }
}
