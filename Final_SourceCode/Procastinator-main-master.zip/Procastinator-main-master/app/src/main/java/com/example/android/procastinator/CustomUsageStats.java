package com.example.android.procastinator;

/**
 * Created by Kevin on 11/18/2017.
 */

import android.app.usage.UsageStats;
import android.graphics.drawable.Drawable;

public class CustomUsageStats {
    public UsageStats usageStats;
    public Drawable appIcon;
}