package com.example.dalyakhatun.procastinator;

import com.firebase.client.Firebase;

/**
 * Created by dalyakhatun on 11/14/17.
 */

public class database extends android.app.Application {
    @Override
    public void onCreate(){
        super.onCreate();
        Firebase.setAndroidContext(this);
    }
}
