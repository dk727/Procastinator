package com.example.dalyakhatun.procastinator;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by dalyakhatun on 10/28/17.
 */

public class set_activityBlockTimer extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.set_activity_block_timer);
    }
}
