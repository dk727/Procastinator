package com.example.dalyakhatun.procastinator;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void displayOnClick(View v){
        if(v.getId()==R.id.activityListButton){
            Intent i = new Intent(MainActivity.this, activity_list.class);
            startActivity(i);
        }
        if(v.getId()==R.id.setActivityBlockButton){
            Intent i = new Intent(MainActivity.this, set_activityBlockTimer.class);
            startActivity(i);
        }
        if(v.getId()== R.id.siteBlockButton){
            Intent i = new Intent(MainActivity.this, siteBlockOnOff.class);
            startActivity(i);
        }
        if(v.getId()==R.id.blockedWebGroupsButton){
            Intent i = new Intent(MainActivity.this, blockedWebsiteGroups.class);
            startActivity(i);
        }
        if(v.getId()==R.id.alertsButton){
            Intent i = new Intent(MainActivity.this, alerts.class);
            startActivity(i);
        }
        if(v.getId()==R.id.activityDataButton){
            Intent i = new Intent(MainActivity.this, myActivityData.class);
            startActivity(i);
        }
    }
}
