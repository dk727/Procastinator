package com.example.dalyakhatun.procastinator;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


/**
 * Created by dalyakhatun on 10/28/17.
 */

public class activity_list extends Activity {
    final Context context = this;
//    Firebase firebaseReferance;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        final Button add_button = (Button) findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                AlertDialog.Builder alert = new AlertDialog.Builder(activity_list.this);
                LayoutInflater inflater=activity_list.this.getLayoutInflater();
                //this is what I did to added the layout to the alert dialog
                View layout=inflater.inflate(R.layout.add_alert,null);
                alert.setView(layout);
                final EditText usernameInput=(EditText)layout.findViewById(R.id.name);

//                final EditText passwordInput=(EditText)layout.findViewById(R.id.name);
                alert.setTitle("Add a new activity");
                alert.setMessage("Please enter a name for the activity");
                alert.show();
//                //connect to the database
//                firebaseReferance = new Firebase("https://procastinator-6533f.firebaseio.com/");
//                Firebase firebaseReferanceChild= firebaseReferance.child("activityName");
//                firebaseReferanceChild.setValue(usernameInput.getText());
            }
        });



    }
}
