package com.example.dalyakhatun.procastinator;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

/**
 * Created by dalyakhatun on 10/28/17.
 */

public class myActivityData extends Activity {
    TextView test;
    Button add_button;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.my_activity_data);
    }

    //

}
