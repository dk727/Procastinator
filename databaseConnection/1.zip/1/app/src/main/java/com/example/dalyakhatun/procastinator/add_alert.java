package com.example.dalyakhatun.procastinator;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.firebase.client.Firebase;

/**
 * Created by dalyakhatun on 11/14/17.
 */

public class add_alert extends Activity {
    Firebase firebaseReferance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_alert);

        final EditText name= (EditText) findViewById(R.id.name);
        Button addAndGoToSetActivity= (Button) findViewById(R.id.addAndGoToSetActivity);
        addAndGoToSetActivity.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //connect to the database
                firebaseReferance = new Firebase("https://procastinator-6533f.firebaseio.com/");
                Firebase firebaseReferanceChild= firebaseReferance.child("activityName");
                firebaseReferanceChild.setValue(name.getText());
                setContentView(R.layout.set_activity_block_timer);
            }
        });


    }
    }

